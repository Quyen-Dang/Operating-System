Compiling instructions:

1. Open terminal

2. Direction to the files.

3. Type make

4. To see the output:

 - Mac OS:

./rwmain.out

 - Windows:

./rwmain.exe

 - Linux:

./rwmain  
